exports.menu = (prefix) => {
    return `*SIMPLE MENU*
• ${prefix}sticker
• ${prefix}attp
• ${prefix}nulis

*GROUP MENU*
• ${prefix}add
• ${prefix}kick
• ${prefix}welcome
• ${prefix}left
• ${prefix}setwelcome
• ${prefix}changewelcome
• ${prefix}delsetwelcome
• ${prefix}setleft
• ${prefix}changeleft
• ${prefix}delsetleft
• ${prefix}mute
• ${prefix}hidetag
• ${prefix}opengrup
• ${prefix}closegrup
• ${prefix}antilink
• ${prefix}antiwame

*DOWNLOAD MENU*
• ${prefix}instagram
• ${prefix}youtube
• ${prefix}tiktok

*STORE MENU*
• ${prefix}addrespon
• ${prefix}delrespon
• ${prefix}update
• ${prefix}addlist
• ${prefix}dellist
• ${prefix}updatelist
• ${prefix}list
• y < reply orderan >
• d < reply orderan >

*OWNER MENU*
• ${prefix}bc
• ${prefix}setlogo
• ${prefix}setprefix
• ${prefix}exif
• ${prefix}public
• ${prefix}self
• ${prefix}ban
• ${prefix}unban
• ${prefix}join
• ${prefix}addsewa
• ${prefix}delsewa
`
}
