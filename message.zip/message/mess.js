module.exports.mess = {
	        wait: '[❗] PROSES....',
			success: 'NI HASILNYA KAK ^_^',
			wrongFormat: 'Format Salah ❌',
			error: {
				api: 'APINYA HABIS BRO 🙏🏻 \nKALAU MAU NYUMBANG KETIK : #donasi',
				stick: 'ITU BUKAN STIKER COEG 🗿',
				Iv: 'JANGAN NGASIH LINK GAJE DONG'
			},
			only: {
				group: 'KHUSUS GRUP BRO',
				admin: 'KHUSUS ADMIN GRUP BRO',
				premium: 'LU BUKAN MEMBER PREMIUM, BELI DULU SANA ❗ \nKETIK : #buyprem',
				owner: 'KHUSUS OWNER BRO',
				Badmin: 'BOT HARUS JADI ADMIN BRO',
			}
		}